<?php include_once('includes/header1.php');?>
	<header>
		<div class="container">
			<?php include_once('includes/navbar.php');?>
		</div>
	</header>

	<section id="showcase">
		<div class="container">
			<h1>Customer Experience Enhancement System</h1>
			<p>Designed for Restaurants and Dining Cafes </p>
		</div>
	</section>
	<!--<footer>
		<p>Team Halcyon web design, copyright &copy; 2017</p>
	</footer>-->
</body>
</html>