<div class="row">
	<div class="span12">
		<ul class="nav nav-tabs">
			<li  ><?php echo anchor('login/admin','Home');?></li>
			<li ><?php echo anchor('login/signup','SystemUsers');?></li>
			<!--<li ><?php// echo anchor('login/meals','Meals');?></li>
			<li ><?php// echo anchor('Menu_con/menu','Menu');?></li>
			<li><?php// echo anchor('login/beverage','Beverages');?></li>-->
			<li ><?php echo anchor('Menu_con/menu','Menu');?></li>
			<li><a href="#">Order</a></li>
			<li><a href="#">Updates and Promotions</a></li>
			<li><a href="#">Reports</a></li>
		</ul>
	</div>


</div>