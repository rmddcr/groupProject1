<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="<?php echo base_url();?>js/home.js" type="text/javascript"></script>
<footer class="footer">
	<div class="container">
		<span class="text-muted">Team Halcyon web design, copyright &copy; 2017</span>
	</div>
</footer>
</body>
</html>