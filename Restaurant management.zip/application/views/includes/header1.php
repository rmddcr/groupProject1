<!DOCTYPE html>
<html lang="en">
<head>
	<title>CRM</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link href="https://fonts.googleapis.com/css?family=Just+Another+Hand" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="<?php echo base_url();?>css/style1.css" type="text/css">
	<link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.css" type="text/css">
</head>
<body>