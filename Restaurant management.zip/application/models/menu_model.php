<?php

class Menu_model extends CI_Model{
	
}
?>